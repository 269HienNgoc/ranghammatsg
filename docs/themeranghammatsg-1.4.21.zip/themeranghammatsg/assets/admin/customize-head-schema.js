/**
 * Tùy biến → "Schema tùy chỉnh (head)": ô CodeMirror kéo đổi chiều cao (CSS resize: vertical).
 * Mỗi lần đổi cỡ → cm.refresh() để CodeMirror vẽ lại đúng vùng; chiều cao lưu localStorage (chỉ trình duyệt này).
 */
( function ( api ) {
	const KEY = 'rhmHeadSchemaHeight';

	api.control( 'rhm_head_schema', function ( control ) {
		control.deferred.codemirror.done( function ( cm ) {
			const wrap = cm.getWrapperElement();

			try {
				const saved = parseInt( window.localStorage.getItem( KEY ), 10 );
				if ( saved >= 120 ) {
					wrap.style.height = saved + 'px';
				}
			} catch ( e ) {}

			let timer;
			new ResizeObserver( function () {
				cm.refresh();
				clearTimeout( timer );
				timer = setTimeout( function () {
					if ( wrap.offsetHeight >= 120 ) {
						try {
							window.localStorage.setItem( KEY, String( wrap.offsetHeight ) );
						} catch ( e ) {}
					}
				}, 300 );
			} ).observe( wrap );
		} );
	} );
} )( wp.customize );
