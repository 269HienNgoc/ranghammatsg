<?php
/**
 * Schema JSON-LD tự viết, in vào <head> mọi trang (Tùy biến → "Schema tùy chỉnh (head)").
 *
 * Độc lập với inc/schema.php (bổ sung graph Yoast): mỗi khối JSON người dùng nhập in thành 1 <script type="application/ld+json">,
 * đặt ngay dưới "<!-- / Yoast SEO plugin. -->".
 * JSON được decode rồi encode lại (JSON_HEX_TAG) trước khi in → không thể chèn HTML/thoát khỏi thẻ <script>.
 * JSON lỗi bị Customizer chặn khi lưu (validate_callback) → schema hỏng không lên site.
 *
 * @package themeranghammatsg
 */

defined( 'ABSPATH' ) || exit;

/**
 * Tách chuỗi nhập thành các khối JSON (chưa decode).
 * Có thẻ <script …>…</script> → mỗi thẻ 1 khối; không có → cả chuỗi là 1 khối.
 *
 * @return string[]
 */
function rhm_head_schema_raw_blocks( string $raw ): array {
	$raw = trim( $raw );
	if ( '' === $raw ) {
		return array();
	}

	if ( preg_match_all( '~<script\b[^>]*>(.*?)</script\s*>~is', $raw, $m ) ) {
		return array_values( array_filter( array_map( 'trim', $m[1] ), 'strlen' ) );
	}

	return array( $raw );
}

/**
 * Các khối schema đã decode (bỏ khối lỗi). Rỗng khi ô trống.
 *
 * @return array<int, array|object>
 */
function rhm_head_schema_blocks( string $raw ): array {
	$blocks = array();
	foreach ( rhm_head_schema_raw_blocks( $raw ) as $json ) {
		$data = json_decode( $json );
		if ( JSON_ERROR_NONE === json_last_error() && ( is_array( $data ) || is_object( $data ) ) ) {
			$blocks[] = $data;
		}
	}
	return $blocks;
}

/**
 * Customizer: từ chối lưu khi có khối không phải JSON object/array hợp lệ.
 *
 * @param WP_Error $validity
 */
function rhm_validate_head_schema( $validity, $value ) {
	foreach ( rhm_head_schema_raw_blocks( (string) $value ) as $i => $json ) {
		$data = json_decode( $json );
		if ( JSON_ERROR_NONE !== json_last_error() ) {
			$validity->add(
				'rhm_head_schema_invalid',
				/* translators: 1: block number, 2: JSON error message */
				sprintf( __( 'Khối schema số %1$d không phải JSON hợp lệ: %2$s', 'themeranghammatsg' ), $i + 1, json_last_error_msg() )
			);
		} elseif ( ! is_array( $data ) && ! is_object( $data ) ) {
			/* translators: %d: block number */
			$validity->add( 'rhm_head_schema_invalid', sprintf( __( 'Khối schema số %d phải là object {…} hoặc mảng […].', 'themeranghammatsg' ), $i + 1 ) );
		}
	}
	return $validity;
}

/** Giữ nguyên định dạng người dùng viết (chỉ trim); an toàn nhờ encode lại khi in. */
function rhm_sanitize_head_schema( $value ): string {
	return trim( (string) $value );
}

/**
 * In các khối schema vào <head>, NGAY DƯỚI dòng "<!-- / Yoast SEO plugin. -->".
 *
 * Yoast in cả khối (từ comment mở tới comment đóng) trong action wpseo_head priority -9999 → hook wpseo_head priority 99
 * in ngay sau comment đóng. Yoast tắt → in ở wp_head priority 2 (đầu <head>). Chỉ in 1 lần mỗi request.
 * class="rhm-head-schema": mu-plugin 0-rhm-head-order.php dựa vào class này để kéo các khối theo khối Yoast khi đưa lên đầu <head>.
 */
function rhm_print_head_schema(): void {
	static $printed = false;
	if ( $printed ) {
		return;
	}
	$printed = true;

	// Nén (mặc định): 1 dòng. Không nén: xuống dòng + thụt lề (JSON_PRETTY_PRINT). Cả 2 đều encode lại + JSON_HEX_TAG.
	$flags  = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG;
	$pretty = ! get_theme_mod( 'rhm_head_schema_minify', true );
	if ( $pretty ) {
		$flags |= JSON_PRETTY_PRINT;
	}
	$nl = $pretty ? "\n" : '';

	foreach ( rhm_head_schema_blocks( (string) get_theme_mod( 'rhm_head_schema', '' ) ) as $data ) {
		$json = wp_json_encode( $data, $flags );
		if ( $json ) {
			echo '<script type="application/ld+json" class="rhm-head-schema">' . $nl . $json . $nl . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON encode lại, JSON_HEX_TAG.
		}
	}
}
add_action( 'wpseo_head', 'rhm_print_head_schema', 99 );

/** Yoast không bật → vẫn in (đầu <head>). */
function rhm_print_head_schema_fallback(): void {
	if ( ! did_action( 'wpseo_head' ) ) {
		rhm_print_head_schema();
	}
}
add_action( 'wp_head', 'rhm_print_head_schema_fallback', 2 );

/**
 * Tùy biến → "Schema tùy chỉnh (head)".
 */
function rhm_customize_head_schema( WP_Customize_Manager $wp_customize ): void {
	$wp_customize->add_section(
		'rhm_head_schema',
		array(
			'title'       => __( 'Schema tùy chỉnh (head)', 'themeranghammatsg' ),
			'description' => esc_html__( 'Dán schema JSON-LD tự viết, in vào thẻ <head> của MỌI trang. Có thể dán kèm hoặc không kèm thẻ <script type="application/ld+json">; nhiều khối thì mỗi khối bọc trong 1 thẻ <script>. JSON lỗi sẽ không lưu được. Lưu ý: Yoast SEO đã in Organization / WebSite / WebPage — tránh khai báo trùng, dùng "@id" để nối vào các thực thể đó. Kiểm tra bằng search.google.com/test/rich-results sau khi lưu.', 'themeranghammatsg' ),
			'priority'    => 160,
		)
	);

	$wp_customize->add_setting(
		'rhm_head_schema',
		array(
			'default'           => '',
			'transport'         => 'refresh',
			'sanitize_callback' => 'rhm_sanitize_head_schema',
			'validate_callback' => 'rhm_validate_head_schema',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Code_Editor_Control(
			$wp_customize,
			'rhm_head_schema',
			array(
				'label'       => __( 'Schema JSON-LD', 'themeranghammatsg' ),
				'description' => __( 'Kéo góc dưới bên phải ô để đổi chiều cao (trình duyệt này nhớ chiều cao đã chỉnh).', 'themeranghammatsg' ),
				'section'     => 'rhm_head_schema',
				'code_type'   => 'application/json',
			)
		)
	);

	$wp_customize->add_setting(
		'rhm_head_schema_minify',
		array(
			'default'           => true,
			'transport'         => 'refresh',
			'sanitize_callback' => 'rest_sanitize_boolean',
		)
	);

	$wp_customize->add_control(
		'rhm_head_schema_minify',
		array(
			'label'       => __( 'Nén schema (minify)', 'themeranghammatsg' ),
			'description' => __( 'Bật: mỗi khối in trên 1 dòng (nhẹ nhất, khuyên dùng). Tắt: in xuống dòng + thụt lề cho dễ đọc khi xem mã nguồn trang. Google đọc như nhau.', 'themeranghammatsg' ),
			'section'     => 'rhm_head_schema',
			'type'        => 'checkbox',
		)
	);
}
add_action( 'customize_register', 'rhm_customize_head_schema', 11 );

/**
 * Customizer: ô schema kéo đổi chiều cao được (assets/admin/customize-head-schema.{css,js}).
 */
function rhm_customize_head_schema_assets(): void {
	wp_enqueue_style( 'rhm-customize-head-schema', RHM_THEME_URI . '/assets/admin/customize-head-schema.css', array( 'customize-controls' ), rhm_asset_version( 'assets/admin/customize-head-schema.css' ) );
	wp_enqueue_script( 'rhm-customize-head-schema', RHM_THEME_URI . '/assets/admin/customize-head-schema.js', array( 'customize-controls' ), rhm_asset_version( 'assets/admin/customize-head-schema.js' ), true );
}
add_action( 'customize_controls_enqueue_scripts', 'rhm_customize_head_schema_assets' );
