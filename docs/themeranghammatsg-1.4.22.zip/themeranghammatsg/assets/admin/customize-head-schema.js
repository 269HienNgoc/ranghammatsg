/**
 * Tùy biến → "Schema tùy chỉnh (head)":
 * 1. Ô CodeMirror kéo đổi chiều cao (CSS resize: vertical). Mỗi lần đổi cỡ → cm.refresh(); chiều cao lưu localStorage (chỉ trình duyệt này).
 * 2. Kiểm tra lỗi JSON theo khối, khớp rhm_head_schema_raw_blocks() (inc/head-schema.php): có thẻ <script>…</script> → kiểm
 *    phần JSON bên trong từng thẻ (dòng báo lỗi = dòng thật trong ô); không có → kiểm cả ô. Thay lint JSON mặc định của WP,
 *    vốn coi cả ô là 1 JSON → báo "Parse error on line 1" (và chặn nút Đăng) khi dán kèm thẻ <script>.
 */
( function ( api ) {
	const KEY = 'rhmHeadSchemaHeight';

	/** Các khối JSON + vị trí bắt đầu (index ký tự) trong ô. */
	function blocks( text ) {
		const list = [];
		const re = /<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi;
		let m;
		while ( ( m = re.exec( text ) ) ) {
			list.push( { code: m[ 1 ], start: m.index + m[ 0 ].indexOf( '>' ) + 1 } );
		}
		return list.length ? list : [ { code: text, start: 0 } ];
	}

	function lintSchema( text ) {
		const found = [];
		const parser = window.jsonlint && ( window.jsonlint.parser || window.jsonlint );
		if ( ! parser || ! text.trim() ) {
			return found;
		}
		const Pos = wp.CodeMirror.Pos;

		blocks( text ).forEach( function ( block ) {
			if ( ! block.code.trim() ) {
				return;
			}
			const before = text.slice( 0, block.start ).split( '\n' );
			const lineOffset = before.length - 1; // Dòng (0-based) của ký tự đầu khối.
			const colOffset = before[ before.length - 1 ].length; // Cột của ký tự đầu khối (chỉ áp cho dòng đầu khối).
			const toPos = function ( line, col ) {
				return Pos( lineOffset + line - 1, ( 1 === line ? colOffset : 0 ) + col );
			};
			parser.parseError = function ( message, hash ) {
				const loc = hash.loc;
				found.push( {
					from: toPos( loc.first_line, loc.first_column ),
					to: toPos( loc.last_line, loc.last_column ),
					message: message.replace( /line (\d+)/, function ( all, n ) {
						return 'line ' + ( lineOffset + parseInt( n, 10 ) );
					} ),
					severity: 'error',
				} );
				throw new Error( 'rhm-schema-lint' ); // Dừng parse khối này ở lỗi đầu tiên.
			};
			try {
				parser.parse( block.code );
			} catch ( e ) {}
		} );
		return found;
	}

	api.control( 'rhm_head_schema', function ( control ) {
		control.deferred.codemirror.done( function ( cm ) {
			const wrap = cm.getWrapperElement();

			// Lint theo khối; vẫn báo lỗi lên control (chặn Đăng khi JSON sai, như server).
			cm.setOption( 'lint', {
				getAnnotations: lintSchema,
				onUpdateLinting: function ( annotations ) {
					control.onUpdateErrorNotice( annotations.filter( ( a ) => 'error' === a.severity ) );
				},
			} );

			try {
				const saved = parseInt( window.localStorage.getItem( KEY ), 10 );
				if ( saved >= 120 ) {
					wrap.style.height = saved + 'px';
				}
			} catch ( e ) {}

			let timer;
			new ResizeObserver( function () {
				cm.refresh();
				clearTimeout( timer );
				timer = setTimeout( function () {
					if ( wrap.offsetHeight >= 120 ) {
						try {
							window.localStorage.setItem( KEY, String( wrap.offsetHeight ) );
						} catch ( e ) {}
					}
				}, 300 );
			} ).observe( wrap );
		} );
	} );
} )( wp.customize );
