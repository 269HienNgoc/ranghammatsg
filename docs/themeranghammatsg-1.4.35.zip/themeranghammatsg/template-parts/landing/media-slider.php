<?php
/**
 * Landing – Ảnh slider + chữ (nhiều item): tiêu đề section (H2, canh giữa) + mô tả → lưới item (1/2/3 cột từ 1024px).
 * Mỗi item = thẻ nền gradient mint → trắng: slider ảnh + tiêu đề (H3) + nội dung. Vị trí ảnh chung cho mọi item
 * (image_position, mặc định phải) và độ rộng ảnh khi trái/phải (image_width, mặc định 3/5); < 640px luôn ảnh trên, chữ dưới.
 * Ảnh so le (alternate, 2026-11-26): ảnh trái/phải + 1 cột → item 1 theo image_position, item 2 đảo phía, item 3 như item 1…
 * (2/3 cột bỏ qua). Chỉ đổi class theo item, sizes giữ nguyên (cùng tỉ lệ ảnh).
 * Field: inc/landing/layouts/media-slider.php. Thiếu tiêu đề section hoặc không có item hợp lệ → không hiện.
 * Chế độ slider (field slider bật VÀ số item > số cột): các item trên 1 hàng trượt ngang, ≥ 1024px N item / khung,
 * < 1024px thẻ 88% (hé thẻ kế); nút ‹ › chuyển item (rhm_landing_tiles_nav()) ≥ 1024px ở 2 mép trái / phải slider
 * (2026-11-26, người dùng yêu cầu), < 1024px hoặc section đứng đầu trang (tràn màn hình, cột nút liên hệ nhanh che mép
 * phải) → dưới slider. Slider lồng nhau: _tiles.js chỉ lấy khối nút của chính [data-rhm-tiles].
 *
 * Hiệu năng / truy cập:
 * - DOM mỗi thẻ luôn ảnh → chữ (= thứ tự mobile); vị trí phải / dưới đảo bằng sm:order-last (chỉ CSS).
 * - Slider native scroll-snap (vuốt được khi chưa có JS), khung ảnh 4:3 cố định + object-cover → CLS = 0.
 * - Item ≥ 2 ảnh: nút ‹ › do _tiles.js xử lý (carousel.js nạp động khi có [data-rhm-tiles-controls]); mỗi track có id
 *   riêng, nút trỏ track qua aria-controls → nhiều slider trong 1 section. Không Swiper.
 * - Chỉ ảnh đầu của item đầu, khi section đứng đầu trang, mới là ảnh LCP; còn lại lazy.
 *
 * @package themeranghammatsg
 */

defined( 'ABSPATH' ) || exit;

$rhm_data    = $args['data'] ?? array();
$rhm_h3_attr = rhm_landing_color_attr( rhm_landing_color( $rhm_data, 'h3_color' ) ); // Màu mọi H3 của section ('' = màu thiết kế).
$rhm_title   = rhm_landing_text( $rhm_data, 'title' );

$rhm_items = array();
foreach ( rhm_landing_rows( $rhm_data, 'items' ) as $rhm_row ) {
	$rhm_images = rhm_landing_gallery( $rhm_row, 'images' );
	$rhm_name   = rhm_landing_text( $rhm_row, 'title' );
	$rhm_text   = rhm_landing_rich( $rhm_row, 'text' );
	if ( $rhm_images || '' !== $rhm_name || '' !== $rhm_text ) {
		$rhm_items[] = array( $rhm_images, $rhm_name, $rhm_text );
	}
}
if ( '' === $rhm_title || ! $rhm_items ) {
	return;
}

$rhm_position = (string) ( $rhm_data['image_position'] ?? 'right' );
$rhm_position = in_array( $rhm_position, array( 'left', 'right', 'top', 'bottom' ), true ) ? $rhm_position : 'right';
$rhm_side     = in_array( $rhm_position, array( 'left', 'right' ), true );
$rhm_columns  = (int) ( $rhm_data['columns'] ?? 1 );
$rhm_columns  = in_array( $rhm_columns, array( 1, 2, 3 ), true ) ? $rhm_columns : 1;
$rhm_alternate = $rhm_side && 1 === $rhm_columns && ! empty( $rhm_data['alternate'] );
$rhm_id       = $args['id'];
$rhm_slider   = ! empty( $rhm_data['slider'] ) && count( $rhm_items ) > $rhm_columns;
$rhm_list_id  = $rhm_id . '-track'; // Track item; track ảnh trong thẻ là <id>-item-N-track → không trùng.
$rhm_head_id  = $rhm_id . '-title';

// Độ rộng ảnh khi cạnh nhau (field image_width, mặc định 3/5): [phần ảnh, lưới ảnh trái, lưới ảnh phải].
// Cột đầu lưới = phần tử đứng trước sau khi đảo order (ảnh phải → chữ trước). Class viết nguyên văn để Tailwind quét được.
$rhm_ratio = match ( (string) ( $rhm_data['image_width'] ?? '60' ) ) {
	'33'    => array( 1 / 3, 'sm:grid-cols-[minmax(0,1fr)_minmax(0,2fr)]', 'sm:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]' ),
	'40'    => array( 0.4, 'sm:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]', 'sm:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]' ),
	'50'    => array( 0.5, 'sm:grid-cols-2', 'sm:grid-cols-2' ),
	'67'    => array( 2 / 3, 'sm:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]', 'sm:grid-cols-[minmax(0,1fr)_minmax(0,2fr)]' ),
	default => array( 0.6, 'sm:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]', 'sm:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]' ),
};
$rhm_frac  = round( $rhm_ratio[0], 4 );

// sizes: khung W = 1248px (≥ 1280px) | 100vw − 32px. Thẻ: viền 1 + đệm 20 (lg 24) mỗi bên → nội dung = thẻ − 42 (lg − 50).
// Cạnh nhau: ảnh = (nội dung − khoảng cách cột 16 | lg 24) × phần ảnh. Lưới thẻ cách 24px, nhiều cột chỉ từ 1024px.
// < 640px xếp dọc: 100vw − 32 − 42 = 100vw − 74px. 640–1023px: thẻ rộng hết khung → cạnh nhau (100vw − 74 − 16) × phần ảnh.
// 1 cột: thẻ = W → cạnh nhau (1248 − 50 − 24) = 1174 | 100vw − 106; trên/dưới 1198 | 100vw − 82.
// 2 cột: thẻ = (W − 24) / 2 = 612 | 50vw − 28 → cạnh nhau 538 | 50vw − 102; trên/dưới 562 | 50vw − 78.
// 3 cột: thẻ = (W − 48) / 3 = 400 | 33.33vw − 27 → cạnh nhau 326 | 33.33vw − 101; trên/dưới 350 | 33.33vw − 77.
// 1024–1479px dư nhẹ do chừa chỗ cột nút liên hệ nhanh (giống các section khác).
// Slider: ≥ 1024px thẻ rộng như lưới (N thẻ cách 24px) → không đổi; < 1024px thẻ = 88% × (100vw − 32) = 88vw − 28
// → xếp dọc 88vw − 70px, cạnh nhau (640–1023px) (88vw − 86px) × phần ảnh.
$rhm_m_stack = $rhm_slider ? '88vw - 70px' : '100vw - 74px';
if ( $rhm_side ) {
	[ $rhm_px, $rhm_vw ] = match ( $rhm_columns ) {
		2       => array( 538, '50vw - 102px' ),
		3       => array( 326, '33.33vw - 101px' ),
		default => array( 1174, '100vw - 106px' ),
	};
	$rhm_sizes = sprintf(
		'(max-width: 639px) calc(%4$s), (min-width: 1280px) %1$dpx, (min-width: 1024px) calc((%2$s) * %3$s), calc((%5$s) * %3$s)',
		(int) ceil( $rhm_px * $rhm_ratio[0] ),
		$rhm_vw,
		$rhm_frac,
		$rhm_m_stack,
		$rhm_slider ? '88vw - 86px' : '100vw - 90px'
	);
} else {
	$rhm_sizes = match ( $rhm_columns ) {
		2       => '(min-width: 1280px) 562px, (min-width: 1024px) calc(50vw - 78px), calc(' . $rhm_m_stack . ')',
		3       => '(min-width: 1280px) 350px, (min-width: 1024px) calc(33.33vw - 77px), calc(' . $rhm_m_stack . ')',
		default => '(min-width: 1280px) 1198px, (min-width: 1024px) calc(100vw - 82px), calc(' . $rhm_m_stack . ')',
	};
}

$rhm_grid   = match ( $rhm_columns ) {
	2       => 'grid gap-5 lg:grid-cols-2 lg:gap-6',
	3       => 'grid gap-5 lg:grid-cols-3 lg:gap-6',
	default => 'grid gap-5 lg:gap-6',
};
// Slider: track + độ rộng thẻ (class nguyên văn). Đệm 8px ngang / 12px dọc + lề âm (≥ 1024px): bóng thẻ không bị
// overflow của track cắt; scroll-padding giữ điểm dừng thẳng mép khung. Thẻ ≥ 1024px = (khung − (N − 1) × 24px) / N.
if ( $rhm_slider ) {
	$rhm_grid  = '-mx-4 flex snap-x snap-mandatory scroll-px-4 gap-5 overflow-x-auto overscroll-x-contain px-4 pb-2 [scrollbar-width:none] lg:-mx-2 lg:-my-3 lg:scroll-px-2 lg:gap-6 lg:px-2 lg:py-3';
	$rhm_slide = match ( $rhm_columns ) {
		2       => ' w-[88%] shrink-0 snap-start lg:w-[calc((100%-24px)/2)]',
		3       => ' w-[88%] shrink-0 snap-start lg:w-[calc((100%-48px)/3)]',
		default => ' w-[88%] shrink-0 snap-start lg:w-full',
	};
	rhm_landing_enqueue_module( 'carousel' ); // carousel.js nạp _tiles.js khi có [data-rhm-tiles-controls].
}
// Class theo vị trí ảnh: [thẻ, bố cục, khối ảnh]. Tính cho cả phía ngược để ảnh so le chỉ cần tra theo item.
// Thẻ: gradient nhạt dần về phía chữ. Cạnh nhau: khung cao hết thẻ (thẻ cùng hàng cao hơn → ảnh + chữ vẫn canh giữa
// theo chiều dọc); 640px+: ảnh / chữ theo $rhm_ratio, mọi số cột. Ảnh phải / dưới: sm:order-last (DOM luôn ảnh → chữ).
$rhm_variant = static function ( string $position ) use ( $rhm_side, $rhm_ratio ): array {
	return array(
		'left' === $position
			? 'overflow-hidden rounded-lg border border-line bg-linear-to-l from-mint to-white p-4 shadow-card lg:p-4'
			: 'overflow-hidden rounded-lg border border-line bg-linear-to-r from-mint to-white p-4 shadow-card lg:p-4',
		$rhm_side
			? 'flex h-full flex-col gap-4 sm:grid sm:items-center lg:gap-6 ' . ( 'left' === $position ? $rhm_ratio[1] : $rhm_ratio[2] )
			: 'flex h-full flex-col gap-4 lg:gap-5',
		in_array( $position, array( 'right', 'bottom' ), true ) ? 'relative min-w-0 sm:order-last' : 'relative min-w-0',
	);
};
$rhm_variants = array( $rhm_variant( $rhm_position ) );
if ( $rhm_alternate ) {
	$rhm_variants[] = $rhm_variant( 'left' === $rhm_position ? 'right' : 'left' );
}
// Lớp nút ‹ › ảnh trong thẻ. Chế độ slider ≥ 1024px: nút item nằm đè nửa lên mép slider → lùi nút ảnh vào thêm 20px
// (lg:px-7) để 2 cặp nút không sát nhau (đo 2026-11-26: còn cách 3px khi ảnh Trái/Phải).
$rhm_img_nav = $rhm_slider
	? 'pointer-events-none invisible absolute inset-x-0 top-0 flex aspect-[4/3] items-center justify-between px-2 lg:px-7'
	: 'pointer-events-none invisible absolute inset-x-0 top-0 flex aspect-[4/3] items-center justify-between px-2';
$rhm_arrow  = 'pointer-events-auto flex size-9 cursor-pointer items-center justify-center rounded-full border border-line bg-white/90 text-primary shadow-card transition-colors hover:bg-primary hover:text-white disabled:cursor-default disabled:opacity-0';
$rhm_rich   = rhm_landing_rich( $rhm_data, 'description' );
?>
<section id="<?php echo esc_attr( $rhm_id ); ?>" class="py-6 lg:py-8" aria-labelledby="<?php echo esc_attr( $rhm_head_id ); ?>">
	<div class="site-container">
		<?php rhm_landing_heading( $rhm_head_id, $rhm_title, rhm_landing_text( $rhm_data, 'eyebrow' ), '', 'center', rhm_landing_color( $rhm_data, 'title_color' ) ); ?>
		<?php if ( '' !== $rhm_rich ) : ?>
			<div class="rhm-rich mx-auto -mt-2 mb-6 max-w-4xl text-center leading-relaxed text-body/85 lg:mb-8"><?php echo $rhm_rich; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- rhm_landing_rich(). ?></div>
		<?php endif; ?>

		<?php if ( $rhm_slider ) : ?>
			<div class="relative" data-rhm-tiles>
		<?php endif; ?>
		<ul<?php echo $rhm_slider ? ' id="' . esc_attr( $rhm_list_id ) . '" aria-labelledby="' . esc_attr( $rhm_head_id ) . '" tabindex="0" data-rhm-tiles-track' : ''; ?> class="<?php echo esc_attr( $rhm_grid ); ?>">
			<?php foreach ( $rhm_items as $rhm_n => [ $rhm_images, $rhm_name, $rhm_text ] ) : ?>
				<?php
				$rhm_track = $rhm_id . '-item-' . ( $rhm_n + 1 ) . '-track';
				$rhm_count = count( $rhm_images );
				$rhm_multi = $rhm_count > 1;
				if ( $rhm_multi ) {
					rhm_landing_enqueue_module( 'carousel' );
				}
				$rhm_label = '' !== $rhm_name ? $rhm_name : $rhm_title;
				[ $rhm_card, $rhm_layout, $rhm_media ] = $rhm_variants[ $rhm_n % count( $rhm_variants ) ];
				?>
				<li class="<?php echo esc_attr( $rhm_slider ? $rhm_card . $rhm_slide : $rhm_card ); ?>">
					<div class="<?php echo esc_attr( $rhm_images ? $rhm_layout : 'flex h-full flex-col' ); ?>">
						<?php if ( $rhm_images ) : ?>
							<div class="<?php echo esc_attr( $rhm_media ); ?>" data-rhm-tiles>
								<div id="<?php echo esc_attr( $rhm_track ); ?>" class="flex snap-x snap-mandatory overflow-x-auto overscroll-x-contain rounded-md [scrollbar-width:none]" aria-label="<?php echo esc_attr( $rhm_label ); ?>" data-rhm-tiles-track<?php echo $rhm_multi ? ' tabindex="0"' : ''; ?>>
									<?php foreach ( $rhm_images as $rhm_index => $rhm_image ) : ?>
										<div class="relative block aspect-[4/3] w-full shrink-0 snap-start overflow-hidden bg-soft"<?php echo $rhm_multi ? ' role="group" aria-roledescription="' . esc_attr__( 'ảnh', 'themeranghammatsg' ) . '" aria-label="' . esc_attr( ( $rhm_index + 1 ) . ' / ' . $rhm_count ) . '"' : ''; ?>>
											<?php
											// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- rhm_html_attrs escape từng thuộc tính.
											echo rhm_landing_picture( $rhm_image, $rhm_sizes, 'absolute inset-0 size-full object-cover', $args['is_first'] && 0 === $rhm_n && 0 === $rhm_index );
											?>
										</div>
									<?php endforeach; ?>
								</div>

								<?php if ( $rhm_multi ) : ?>
									<div class="<?php echo esc_attr( $rhm_img_nav ); ?>" data-rhm-tiles-controls>
										<button type="button" class="<?php echo esc_attr( $rhm_arrow ); ?>" aria-label="<?php esc_attr_e( 'Ảnh trước', 'themeranghammatsg' ); ?>" aria-controls="<?php echo esc_attr( $rhm_track ); ?>" data-rhm-tiles-prev disabled>
											<?php echo rhm_get_icon( 'chevron', 'size-5 rotate-90' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?>
										</button>
										<button type="button" class="<?php echo esc_attr( $rhm_arrow ); ?>" aria-label="<?php esc_attr_e( 'Ảnh tiếp theo', 'themeranghammatsg' ); ?>" aria-controls="<?php echo esc_attr( $rhm_track ); ?>" data-rhm-tiles-next disabled>
											<?php echo rhm_get_icon( 'chevron', 'size-5 -rotate-90' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?>
										</button>
									</div>
								<?php endif; ?>
							</div>
						<?php endif; ?>

						<?php if ( '' !== $rhm_name || '' !== $rhm_text ) : ?>
							<div class="min-w-0">
								<?php if ( '' !== $rhm_name ) : ?>
									<h3 class="text-lg leading-snug font-bold text-pretty text-primary lg:text-xl"<?php echo $rhm_h3_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- rhm_landing_color_attr(). ?>><?php echo esc_html( $rhm_name ); ?></h3>
								<?php endif; ?>
								<?php if ( '' !== $rhm_text ) : ?>
									<div class="<?php echo esc_attr( '' !== $rhm_name ? 'rhm-rich mt-2 text-sm leading-relaxed text-body/85 lg:text-[15px]' : 'rhm-rich text-sm leading-relaxed text-body/85 lg:text-[15px]' ); ?>"><?php echo $rhm_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- rhm_landing_rich(). ?></div>
								<?php endif; ?>
							</div>
						<?php endif; ?>
					</div>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php if ( $rhm_slider ) : ?>
				<?php rhm_landing_tiles_nav( $rhm_list_id, empty( $args['is_first'] ), __( 'Item trước', 'themeranghammatsg' ), __( 'Item tiếp theo', 'themeranghammatsg' ) ); ?>
			</div>
		<?php endif; ?>
	</div>
</section>
